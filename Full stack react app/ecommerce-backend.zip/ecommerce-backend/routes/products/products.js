const { Products } = require("../../modal/products/product");
const { Category } = require("../../modal/category/category");
const express = require("express");
const router = express.Router();
const _ = require("lodash");
const multer = require("multer");
const upload = multer({ dest: "upload/" });
const path = require("path");
const asyncMiddleware = require("../../middleware/async");
const { validate } = require("../../middleware/validation");
const { productSchema } = require("../../validation/validationSchema");
// const uploads = require(".././../startup/multer");

// //storage for multer
const Storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "upload");
  },
  filename: (req, file, cb) => {
    cb(null, file.fieldname + "-" + Date.now() + file.originalname);
  },
});

const uploads = multer({
  storage: Storage,
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype == "image/png" ||
      file.mimetype == "image/jpg" ||
      file.mimetype == "image/jpeg"
    ) {
      cb(null, true);
    } else {
      cb(null, false);
      return cb(new Error("Only .png, .jpg and .jpeg format allowed!"));
    }
  },
  // limits: { fileSize: 8192 },
});

// Add product
router.post(
  "/",
  uploads.single("image"),
  validate(productSchema),
  asyncMiddleware(async (req, res) => {
    let { name, price, category, image, description } = req.body;
    image = req.file.path;

    let cat = await Category.find({ categoryName: category });
    if (cat.length === 0) {
      return res.send({
        success: false,
        msg: "Category not found. Please add category first",
      });
    }

    let product = await Products.findOne({ name: req.body.name });
    if (product)
      return res.status(404).send({
        success: false,
        msg: "Product already register.",
      });

    product = new Products({ name, price, category, image, description });
    product.productId = product.generateProductId();

    product = await product.save();
    res.send({
      success: true,
      product,
    });
  })
);

// get all product
router.get(
  "/",
  asyncMiddleware(async (req, res) => {
    const limit = Number(req.query.limit) || 0;

    const sort = req.query.sort == "desc" ? -1 : 1;

    const product = await Products.find().limit(limit).sort({ price: sort });

    res.send({
      success: true,
      product,
    });
  })
);

// delete product
router.delete(
  "/:id",
  asyncMiddleware(async (req, res) => {
    const product = await Products.findByIdAndRemove(req.params.id);

    if (!product)
      return res.status(404).send({
        success: false,
        msg: "The product with the given ID was not found.",
      });

    res.send({
      success: true,
      product,
    });
  })
);

// get single product
router.get(
  "/:id",
  asyncMiddleware(async (req, res) => {
    const productId = req.params.id;
    const product = await Products.findOne({ productId });

    if (!product)
      return res.status(404).send({
        success: false,
        msg: "The product with the given ID was not found.",
      });

    res.send({
      success: true,
      product,
    });
  })
);

// Update product
router.put(
  "/:id",
  asyncMiddleware(async (req, res) => {
    const { name, price, category, description } = req.body;
    const { image } = req.file.path;

    const product = await Products.findByIdAndUpdate(
      req.params.id,
      { name, price, category, image, description },
      { new: true }
    );

    if (!product)
      return res.status(404).send({
        success: false,
        msg: "The product with the given ID was not found.",
      });

    res.send({
      success: true,
      product,
    });
  })
);

module.exports = router;
