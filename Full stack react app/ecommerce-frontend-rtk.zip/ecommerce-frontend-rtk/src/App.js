import "./App.scss";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Dashboard from "./pages/dashboard/Dashboard";
import Admin from "./pages/admin/Admin";
import Register from "./pages/Register/Register";
import Login from "./pages/Login/Login";
import AddProducts from "./pages/products/AddProducts";
import Users from "./pages/users/Users";
import SingleProduct from "./pages/products/SingleProduct";
import Cart from "./pages/cart/Cart";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import AddressForm from "./pages/Address/addressForm";
import ConfirmOrder from "./pages/confirm order/ConfirmOrder";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        {/* <Appbar /> */}
        <Routes>
          <Route path="/">
            <Route index element={<Dashboard />} />
            <Route path="login" element={<Login />} />
            <Route path="register" element={<Register />} />
            <Route path="admin" element={<Admin />} />
            <Route path="cart" element={<Cart />} />
            <Route path="product/:id" element={<SingleProduct />} />
            <Route path="admin/addproduct" element={<AddProducts />} />
            <Route path="admin/users" element={<Users />} />
            <Route path="users/address" element={<AddressForm />} />
            <Route path="confirmOrder" element={<ConfirmOrder />} />
          </Route>
        </Routes>
        <ToastContainer />
      </BrowserRouter>
    </div>
  );
}

export default App;
