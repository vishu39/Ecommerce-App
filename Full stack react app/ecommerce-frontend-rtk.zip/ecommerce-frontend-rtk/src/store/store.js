import { configureStore } from "@reduxjs/toolkit";
import cartReducer from "./cartSlice";
import productReducer from "./productSlice";
import categoryReducer from "./categorySlice";
import userReducer from "./userSlice";
import authReducer from "./authSlice";
import filterProductReducer from "./filterProductSlice";
import addressReducer from "./addressSlice";
import uReducer from "./singleUserSlice";
import notLoginReducer from "./notLoginSlice";

export const store = configureStore({
  reducer: {
    products: productReducer,
    category: categoryReducer,
    carts: cartReducer,
    users: userReducer,
    auth: authReducer,
    filterProduct: filterProductReducer,
    address: addressReducer,
    singleUser: uReducer,
    notLogin: notLoginReducer,
  },
});
