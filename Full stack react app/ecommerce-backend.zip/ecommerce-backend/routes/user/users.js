const { User } = require("../../modal/user/users");
const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const asyncMiddleware = require("../../middleware/async");
const { validate } = require("../../middleware/validation");
const {
  registerSchema,
  loginSchema,
} = require("../../validation/validationSchema");
const { UserAddress } = require("../../modal/user/address/userAddress");

router.get(
  "/address/:userId",
  asyncMiddleware(async (req, res) => {
    const userId = req.params.userId;
    let address = await UserAddress.find({ userId });
    if (!address) {
      return res.send({
        success: false,
        msg: "Address not found",
      });
    }

    res.send({
      success: true,
      address,
      msg: "Address found",
    });
  })
);

router.post(
  "/address",
  asyncMiddleware(async (req, res) => {
    const { userId, addressLine1, addressLine2, city, state, pincode } =
      req.body;
    let address = await UserAddress.find({ userId });
    if (!address) {
      return res.send({
        success: false,
        msg: "User Address not found",
      });
    }

    address = new UserAddress({
      userId,
      addressLine1,
      addressLine2,
      city,
      state,
      pincode,
    });

    await address.save();

    return res.send({
      success: true,
      address,
      msg: "User Address added successfully",
    });
  })
);

// --------------------------------------------------------------------------------------------------------------------------------------

//Add User

router.post(
  "/signup",
  validate(registerSchema),
  asyncMiddleware(async (req, res) => {
    let user = await User.findOne({ email: req.body.email });
    if (user)
      return res
        .status(401)
        .send({ success: false, msg: "User already registered." });

    const { name, email, password, phone } = req.body;

    user = new User({
      name,
      email,
      password,
      phone,
    });

    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(user.password, salt);
    user.userId = user.generateUserId();

    await user.save();

    const token = user.generateAuthToken();

    return res.send({
      success: true,
      user,
      token,
      msg: "User registerd successfully",
    });
  })
);

// Login User
router.post(
  "/login",
  validate(loginSchema),
  asyncMiddleware(async (req, res) => {
    let user = await User.findOne({ email: req.body.email });

    if (!user) {
      return res.status(401).send({
        success: false,
        msg: "User Not Found.",
      });
    }

    const comparePassword = await bcrypt.compare(
      req.body.password,
      user.password
    );

    if (!comparePassword) {
      return res
        .status(400)
        .send({ success: false, message: "Error!.. Password is not valid." });
    }

    const token = user.generateAuthToken();
    return res.send({
      success: true,
      token,
    });
  })
);

// Get All User
router.get(
  "/",
  asyncMiddleware(async (req, res) => {
    const limit = req.query.limit;
    const sort = req.query.sort == "desc" ? -1 : 1;
    const user = await User.find().limit(limit).sort({ id: sort });
    res.send({
      success: true,
      user,
    });
  })
);

// Delete User
router.delete(
  "/:id",
  asyncMiddleware(async (req, res) => {
    const _id = req.params.id;
    const user = await User.findByIdAndRemove({ _id });
    if (!user)
      return res.status(404).send({
        success: false,
        msg: "The user with the given ID was not found.",
      });
    res.send({
      success: true,
      user,
    });
  })
);

// Get Single User
router.get(
  "/:id",
  asyncMiddleware(async (req, res) => {
    const userId = req.params.id;
    const user = await User.findOne({ userId });
    if (!user)
      return res.status(404).send({
        success: false,
        msg: "The user with the given ID was not found.",
      });
    res.send({
      success: true,
      user,
    });
  })
);

// Edit User
router.put(
  "/:id",
  asyncMiddleware(async (req, res) => {
    const { name, email, password, phone } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      {
        name,
        email,
        phone,
        password,
      },
      { new: true }
    );
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(user.password, salt);

    if (!user)
      return res.status(404).send({
        success: false,
        msg: "The user with the given ID was not found.",
      });
    res.send({
      success: true,
      user,
    });
  })
);

module.exports = router;

// const _ = require("lodash");

// registerUser = new Register(
//   _.pick(req.body, ["userId", "name", "email", "password", "phone"])
// );

// res
//   .header("x-access-token", token)
//   .send(_.pick(registerUser, ["_id", "userId", "name", "email"]));

// ------------------------------------------------------------------------------
// bcrypt.compare(req.body.password, user.password, (err, result) => {
//   if (!result) {
//     return res.status(400).send({
//       success: false,
//       msg: "Password did not match",
//     });
//   } else {
//     const token = user.generateAuthToken();
//     return res.send({
//       success: true,
//       token,
//     });
//   }
// });
