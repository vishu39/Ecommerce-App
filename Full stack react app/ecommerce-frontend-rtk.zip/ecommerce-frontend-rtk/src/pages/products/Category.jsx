import "./category.scss";
import { Button } from "@mui/material";
import { useSelector } from "react-redux";
import { useEffect } from "react";

function Category(props) {
  const isCategoryLoading = useSelector((state) => state?.category?.loading);
  // const { category, fetchCategory, allCat, higlightFilter } = props;
  const { category, fetchCategory, allCat } = props;

  return (
    <div className="category">
      <Button
        onClick={() => {
          allCat();
        }}
        id="all"
        className="btn"
        variant="contained"
        color="error"
      >
        All Category
      </Button>
      {isCategoryLoading ? (
        <h1>Loading...</h1>
      ) : (
        category?.map((cat, index) => {
          return (
            <Button
              onClick={() => {
                fetchCategory(cat.categoryName);
                // higlightFilter(cat.categoryName);
              }}
              key={index}
              id={cat.categoryName}
              className="btn"
              variant="contained"
              color="error"
            >
              {cat.categoryName}
            </Button>
          );
        })
      )}
    </div>
  );
}

export default Category;
