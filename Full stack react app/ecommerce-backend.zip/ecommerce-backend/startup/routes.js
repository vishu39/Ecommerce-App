const express = require("express");
const users = require("../routes/user/users");
const products = require("../routes/products/products");
const categories = require("../routes/products/categories");
const cart = require("../routes/carts/carts");
const cors = require("cors");
const error = require("../middleware/error");

module.exports = function (app) {
  app.use("/upload", express.static("upload"));
  app.use(express.json());
  app.use(cors());
  app.use("/users", users);
  app.use("/products", products);
  app.use("/categories", categories);
  app.use("/cart", cart);
  app.use(error);
};
