import * as React from "react";
import "./bottombar.scss";
import Box from "@mui/material/Box";
import BottomNavigation from "@mui/material/BottomNavigation";
import BottomNavigationAction from "@mui/material/BottomNavigationAction";
import RestoreIcon from "@mui/icons-material/Restore";
import FavoriteIcon from "@mui/icons-material/Favorite";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import Typography from "@mui/material/Typography";

export default function SimpleBottomNavigation() {
  return (
    <Box className="bn">
      <BottomNavigation>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Facebook
          <BottomNavigationAction label="Recents" icon={<RestoreIcon />} />
        </Typography>

        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Instagram
          <BottomNavigationAction label="Favorites" icon={<FavoriteIcon />} />
        </Typography>

        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Youtube
          <BottomNavigationAction label="Nearby" icon={<LocationOnIcon />} />
        </Typography>
      </BottomNavigation>
    </Box>
  );
}
