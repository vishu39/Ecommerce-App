import "./cart.scss";
import { Button } from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { useSelector, useDispatch } from "react-redux";
import {
  decrementQuantity,
  getCarts,
  incrementQuantity,
} from "../../store/cartSlice";
import Appbar from "../../components/toolbar/Toolbar";
import { updateCart, deleteCart } from "../../services/cartService";

import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { getUser } from "../../services/loginService";
import Axios from "axios";
import {
  decrementNotLoginQuantity,
  incrementNotLoginQuantity,
} from "../../store/notLoginSlice";

function Cart() {
  const dispatch = useDispatch();
  const { userToken, isError, isSuccess, isLoading, message } = useSelector(
    (state) => state.auth
  );
  const token = useSelector((state) => state?.auth?.userToken);
  const carts = useSelector((state) => state?.carts?.carts);
  const notLoginCarts = useSelector((state) => state?.notLogin?.notLoginData);
  const [products, setProducts] = useState([]);
  const [quantity, setQuantity] = useState();
  const user = getUser(token);
  let priceArray = [];
  const navigate = useNavigate();

  useEffect(() => {
    // if (isError) {
    //   toast.error(message);
    // }
    // if (!userToken) {
    //   navigate("/");
    // }
    // dispatch(reset());
    getProduct();
  }, []);

  useEffect(() => {
    if (carts.length === 0 && token) {
      dispatch(getCarts(token));
    }
  }, [token]);

  const getProduct = async () => {
    let array = [];
    if (notLoginCarts.length !== 0) {
      await notLoginCarts.map((cart) => {
        cart.product.map((data) => {
          setQuantity(data?.quantity);
          array.push(data.productId);
        });
      });
    }
    fetchProduct(array);
  };

  const fetchProduct = async (array) => {
    let data = [];
    await array.map((pId) => {
      Axios.get(`http://localhost:9000/products/${pId}`).then((res) => {
        if (res.data.success) {
          data.push(res.data.product);
        }
      });
      setTimeout(() => {
        setProducts(data);
      }, 100);
    });
  };

  const grandTotal = () => {
    let sum = 0;
    for (let i = 0; i < priceArray.length; i++) {
      sum += priceArray[i];
    }
    return sum;
  };

  const deleteCartItem = (cartId) => {
    deleteCart(cartId);
    dispatch(getCarts(token));
  };

  const increment = (index) => {
    dispatch(incrementQuantity(index));
  };

  const decrement = (index) => {
    if (carts[index].products[0].quantity === 1) {
      deleteCart(carts[index].cartId);
      dispatch(getCarts(token));
    }
    dispatch(decrementQuantity(index));
  };

  const backToDashboard = () => {
    carts.forEach((cart) => {
      let body = {
        userId: user?.userId,
        product: [
          {
            productId: cart.products[0].productId,
            quantity: cart.products[0].quantity,
          },
        ],
      };
      updateCart(cart?.cartId, body);
    });
    navigate("/");
  };

  const checkout = () => {
    carts.forEach((cart) => {
      let body = {
        userId: user?.userId,
        product: [
          {
            productId: cart.products[0].productId,
            quantity: cart.products[0].quantity,
          },
        ],
      };
      updateCart(cart?.cartId, body);
    });
    navigate("/confirmOrder");
  };

  return token ? (
    <TableContainer component={Paper} className="cart">
      <Appbar></Appbar>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell align="center">S.No</TableCell>
            <TableCell align="center">Name</TableCell>
            <TableCell align="center">Image</TableCell>
            <TableCell align="center">Category</TableCell>
            <TableCell align="center">Quantity</TableCell>
            <TableCell align="center">Price</TableCell>
            <TableCell align="center">Description</TableCell>
            <TableCell align="center">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {carts?.map((cart, index) => {
            return cart?.products?.map((data) => {
              priceArray.push(data.productDetails.price * data.quantity);
              return (
                <TableRow
                  key={index}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <TableCell align="center">{index + 1}</TableCell>

                  <TableCell align="center">
                    {data.productDetails.name}
                  </TableCell>

                  <TableCell align="center" width="150">
                    <img
                      className="image"
                      src={`http://localhost:9000/${data.productDetails.image}`}
                      alt=""
                    ></img>
                  </TableCell>

                  <TableCell align="center">
                    {data.productDetails.category}
                  </TableCell>

                  <TableCell align="center" width="150">
                    <div className="quantDiv">
                      <Button
                        variant="contained"
                        color="success"
                        className="btn"
                        onClick={() => increment(index)}
                      >
                        +
                      </Button>
                      {data.quantity}
                      <Button
                        variant="contained"
                        color="success"
                        className="btn"
                        onClick={() => decrement(index)}
                      >
                        -
                      </Button>
                    </div>
                  </TableCell>

                  <TableCell align="center">
                    {data.quantity * data.productDetails.price}
                  </TableCell>

                  <TableCell align="center">
                    {data.productDetails.description}
                  </TableCell>

                  <TableCell align="center">
                    <Button
                      color="error"
                      onClick={() => deleteCartItem(cart.cartId)}
                    >
                      Delete
                    </Button>
                  </TableCell>
                </TableRow>
              );
            });
          })}
        </TableBody>
      </Table>
      <div className="bottom">
        <span className="btn">
          <b>GrandTotal:</b>
          {grandTotal()}
        </span>
        <span>
          <Button
            onClick={() => backToDashboard()}
            className="btn"
            variant="contained"
            color="primary"
          >
            Back To Dashboard
          </Button>
          <Button
            onClick={() => checkout()}
            className="btn"
            variant="contained"
            color="secondary"
          >
            Checkout
          </Button>
        </span>
      </div>
    </TableContainer>
  ) : (
    // ------------------------------------------------------------------------------------
    // -------------------------------------------------------------------------------------
    <TableContainer component={Paper} className="cart">
      <Appbar></Appbar>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell align="center">S.no</TableCell>
            <TableCell align="center">Name</TableCell>
            <TableCell align="center">Image</TableCell>
            <TableCell align="center">Category</TableCell>
            <TableCell align="center">Quantity</TableCell>
            <TableCell align="center">Price</TableCell>
            <TableCell align="center">Description</TableCell>
            <TableCell align="center">Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {products.map((product, index) => {
            return (
              <TableRow
                key={index}
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell align="center">{index + 1}</TableCell>

                <TableCell align="center">{product?.name}</TableCell>

                <TableCell align="center" width="150">
                  <img
                    className="image"
                    src={`http://localhost:9000/${product?.image}`}
                    alt=""
                  ></img>
                </TableCell>

                <TableCell align="center">{product?.category}</TableCell>

                <TableCell align="center" width="150">
                  <div className="quantDiv">
                    <Button
                      variant="contained"
                      color="success"
                      className="btn"
                      onClick={() => dispatch(incrementNotLoginQuantity(index))}
                    >
                      +
                    </Button>
                    {notLoginCarts[index]?.product[0]?.quantity}
                    <Button
                      variant="contained"
                      color="success"
                      className="btn"
                      onClick={() => dispatch(decrementNotLoginQuantity(index))}
                    >
                      -
                    </Button>
                  </div>
                </TableCell>

                <TableCell align="center">{product?.price}</TableCell>

                <TableCell align="center">{product?.description}</TableCell>

                <TableCell align="center">
                  <Button
                    color="error"
                    // onClick={() => deleteCartItem(cart.cartId)}
                    // onClick={() => grandTotal()}
                  >
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      <div className="bottom">
        <span className="btn">
          <b>GrandTotal:</b>
          {grandTotal()}
        </span>
        <span>
          <Button
            onClick={() => navigate("/")}
            className="btn"
            variant="contained"
            color="primary"
          >
            Back To Dashboard
          </Button>
          <Button
            onClick={() =>
              navigate("/confirmOrder", {
                cartData: carts,
                grandTotal: grandTotal,
              })
            }
            className="btn"
            variant="contained"
            color="secondary"
          >
            Checkout
          </Button>
        </span>
      </div>
    </TableContainer>
  );
}

export default Cart;
