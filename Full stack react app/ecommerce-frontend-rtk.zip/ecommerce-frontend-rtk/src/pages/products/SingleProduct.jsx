import "./singleProduct.scss";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Axios from "axios";
import { getUser } from "../../services/loginService";
import { getCarts, updateCart } from "../../store/cartSlice";
import Button from "@mui/material/Button";
import { useDispatch, useSelector } from "react-redux";
import Appbar from "../../components/toolbar/Toolbar";
import { getNotLoginData } from "../../store/notLoginSlice";

function SingleProduct() {
  const dispatch = useDispatch();
  const { id } = useParams();
  const [product, setProduct] = useState([]);
  const [isProductLoading, setisProductLoading] = useState(true);
  const token = useSelector((state) => state?.auth?.userToken);
  const carts = useSelector((state) => state?.carts?.carts);
  const notLoginData = useSelector((state) => state?.notLogin?.notLoginData);
  const navigate = useNavigate();

  useEffect(() => {
    if (carts?.length === 0) {
      dispatch(getCarts(token));
    }
    getProduct();
  }, [token]);

  const addToCart = async () => {
    const user = await getUser(token);

    const body = {
      userId: user?.userId,
      product: [
        {
          productId: product?.productId,
          quantity: 1,
        },
      ],
    };

    if (token) {
      Axios.post("http://localhost:9000/cart", body)
        .then((req, res) => {
          dispatch(getCarts(token));
        })
        .catch((err) => {
          console.log(err);
        });
    }

    if (notLoginData.length === 0) {
      dispatch(getNotLoginData(body));
    }
    let array = [...notLoginData];
    array.push(body);
    dispatch(getNotLoginData(array));
  };

  const getProduct = () => {
    Axios.get(`http://localhost:9000/products/${id}`)
      .then((res) => {
        if (res.data.success) {
          setProduct(res.data.product);
          setisProductLoading(false);
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div className="singleProduct">
      <Appbar />
      {isProductLoading ? (
        <h1>Loading...</h1>
      ) : (
        <div className="main">
          <div className="first">
            <img
              className="image"
              src={`http://localhost:9000/${product.image}`}
              alt=""
            />
          </div>

          <div className="second">
            <h1>Title:{product.name}</h1>
            <h2>Category:{product.category}</h2>
            <h3>Price:{product.price}</h3>
            <img
              width="300"
              height="150"
              src={`http://localhost:9000/${product.image}`}
              alt=""
            />
            <h4>Description:{product.description}</h4>
          </div>
        </div>
      )}
      <span className="lower">
        <Button
          className="btn"
          onClick={() => addToCart()}
          variant="contained"
          color="primary"
        >
          Add to Cart
        </Button>

        <Button
          className="btn"
          onClick={() => navigate("/")}
          variant="contained"
          color="error"
        >
          Back To Dashboard
        </Button>

        <Button className="btn" variant="contained" color="success">
          Buy Now
        </Button>
      </span>
    </div>
  );
}

export default SingleProduct;
