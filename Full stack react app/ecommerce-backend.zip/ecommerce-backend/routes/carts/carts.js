const { Cart } = require("../../modal/carts/carts");
const express = require("express");
const router = express.Router();
const _ = require("lodash");
const { Products } = require("../../modal/products/product");
const { User } = require("../../modal/user/users");
const { validate } = require("../../middleware/validation");
const asyncMiddleware = require("../../middleware/async");
const { cartSchema } = require("../../validation/validationSchema");

router.post(
  "/",
  validate(cartSchema),
  asyncMiddleware(async (req, res) => {
    const { userId, product } = req.body;
    let cart = await Cart.find({ userId });

    if (!cart) {
      return res.send({
        success: false,
        msg: "Cart not found",
      });
    }

    // let productId = product[0].productId;
    // let existingCart = await Cart.findOneAndUpdate({userId,product[0].productId});
    // console.log(existingCart);

    cart = new Cart({
      userId,
      product: [
        {
          productId: product[0].productId,
          quantity: product[0].quantity,
        },
      ],
    });

    // if (cart.product[0].productId === product[0].productId) {
    //   return (cart = Cart.findOneAndReplace({
    //     userId,
    //     product: [
    //       {
    //         productId: product[0].productId,
    //         quantity: product[0].quantity + 1,
    //       },
    //     ],
    //   }));
    // let pro = product[0];
    // console.log(await Cart.find({ userId, pro }));
    // return await Cart.findOneAndUpdate({ userId }, newCart);
    // }

    cart.cartId = cart.generateCartId();
    cart.date = new Date();

    cart = await cart.save();

    res.send({
      success: true,
      cart,
      msg: "cart added successfully",
    });
  })
);

// router.get("/", async (req, res) => {

router.get(
  "/",
  asyncMiddleware(async (req, res) => {
    let cart = await Cart.find();
    res.send({
      success: true,
      cart,
    });
  })
);

router.delete(
  "/:cartId",
  asyncMiddleware(async (req, res) => {
    const { cartId } = req.params;
    let cart = await Cart.findOneAndRemove({ cartId });

    res.send({
      success: true,
      // cart,
      msg: "Cart deleted successfully",
    });
  })
);

router.put(
  "/:cartId",
  asyncMiddleware(async (req, res) => {
    const { cartId } = req.params;
    newCart = {
      userId: req.body.userId,
      product: req.body.product,
    };
    let cart = await Cart.findOneAndUpdate({ cartId }, newCart);

    if (!cart)
      return res.status(404).send({
        success: false,
        msg: "The product with the given ID was not found.",
      });

    res.send({
      success: true,
      cart,
    });
  })
);

const getCartProducts = async (cart) => {
  let { cartId, userId } = cart;
  let products = [];
  for await (let item of cart.product.map(async (product) => {
    let { productId, quantity } = product;
    let productDetails = await Products.find({ productId });
    return { productId, productDetails: productDetails[0], quantity };
  })) {
    products.push(item);
  }
  return { cartId, products, userId };
};

const getAllCarts = async (carts) => {
  let cartData = [];

  for await (let cart of carts.map(async (item) => {
    return getCartProducts(item);
  })) {
    cartData.push(cart);
  }
  return { cartData };
};

router.get(
  "/:userId/",
  asyncMiddleware(async (req, res) => {
    const userId = req.params.userId;
    let cart = await Cart.find({ userId });
    cart = await getAllCarts(cart);
    res.send({
      success: true,
      cart,
    });
  })
);

// router.get(
//   "/:cartId",
//   asyncMiddleware(async (req, res) => {
//     const cartId = req.params.cartId;
//     let cart = await Cart.findOne({ cartId });

//     if (!cart) {
//       return res.status(404).send({
//         success: false,
//         msg: "The product with the given ID was not found.",
//       });
//     }

//     let pro = await Products.findOne({ productId: cart.productId });
//     let cartData = {
//       userId: cart.userId,
//       cartId: cart.cartId,
//       pro,
//       quantity: cart.quantity,
//     };

//     res.send({
//       success: true,
//       cartData,
//     });
//   })
// );

module.exports = router;
