import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import Axios from "axios";

const initialState = {
  loading: false,
  notLoginData: [],
  error: "",
};

const getNotLoginData = createAsyncThunk(
  "notLogin/getNotLoginData",
  async (data) => {
    return data;
  }
);

const notLoginSlice = createSlice({
  name: "notLogin",
  initialState,

  reducers: {
    incrementNotLoginQuantity: (state, action) => {
      let cart = JSON.parse(JSON.stringify(state.notLoginData));
      let nCart = cart[action.payload];
      console.log(nCart);
      let newCart = nCart.product.map((pro) => {
        return {
          productId: pro.productId,
          quantity: pro.quantity + 1,
        };
      });
      newCart.map((nc) => {
        nCart.product[0] = nc;
      });
      cart[action.payload] = nCart;
      state.notLoginData = cart;
    },

    decrementNotLoginQuantity: (state, action) => {
      let cart = JSON.parse(JSON.stringify(state.notLoginData));
      let nCart = cart[action.payload];
      console.log(nCart);
      let newCart = nCart.product.map((pro) => {
        return {
          productId: pro.productId,
          quantity: pro.quantity - 1,
        };
      });
      newCart.map((nc) => {
        nCart.product[0] = nc;
      });
      cart[action.payload] = nCart;
      state.notLoginData = cart;
    },
    // deleteItem:(state,action)=>{
    //   let cart = JSON.parse(JSON.stringify(state.notLoginData));
    //   let nCart = cart[action.payload];
    // }
  },

  extraReducers: (builder) => {
    builder.addCase(getNotLoginData.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getNotLoginData.fulfilled, (state, action) => {
      state.loading = false;
      state.notLoginData = action.payload;
      state.error = "";
    });
    builder.addCase(getNotLoginData.rejected, (state, action) => {
      state.loading = false;
      state.notLoginData = [];
      state.error = action.error.message;
    });
  },
});

export { getNotLoginData };
export const { incrementNotLoginQuantity, decrementNotLoginQuantity } =
  notLoginSlice.actions;
export default notLoginSlice.reducer;
