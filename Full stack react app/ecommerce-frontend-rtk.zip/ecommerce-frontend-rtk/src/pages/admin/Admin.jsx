import React from "react";
import "./admin.scss";
import { useNavigate } from "react-router-dom";
import { Button } from "@mui/material";

function Admin() {
  const navigate = useNavigate();
  return (
    <div className="admin">
      <Button
        className="btn"
        onClick={() => navigate("/")}
        variant="contained"
        color="primary"
      >
        Dashboard
      </Button>
      <Button
        className="btn"
        onClick={() => navigate("addProduct")}
        variant="contained"
        color="secondary"
      >
        Add Product
      </Button>
      <Button
        className="btn"
        onClick={() => navigate("users")}
        variant="contained"
        color="error"
      >
        Users
      </Button>
    </div>
  );
}

export default Admin;
