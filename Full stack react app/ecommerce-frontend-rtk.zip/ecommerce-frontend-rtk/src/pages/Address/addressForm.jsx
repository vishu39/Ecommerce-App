import React from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import { useNavigate } from "react-router-dom";
import "./addressForm.scss";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { getUser } from "../../services/loginService";
import { addAddress } from "../../services/userService";

const schema = yup.object().shape({
  addressLine1: yup.string().required("Address Line 1 is required"),
  addressLine2: yup.string().required("Address Line 2 is required"),
  city: yup.string().required("City is required"),
  state: yup.string().required("State is required"),
  pincode: yup
    .number()
    .transform((value) => (isNaN(value) ? undefined : value))
    .required("Pincode is required"),
});

function AddressForm() {
  const address = useSelector((state) => state?.address?.address);
  const token = useSelector((state) => state?.auth?.userToken);
  const user = getUser(token);
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const submitHandler = (data) => {
    const body = {
      userId: user?.userId,
      ...data,
    };
    addAddress(body);
  };
  return (
    <div className="address">
      <form className="form" onSubmit={handleSubmit(submitHandler)}>
        <div className="heading">
          <h1>User Address</h1>
        </div>

        <div className="inputDiv">
          <TextField
            {...register("addressLine1")}
            className="inp"
            label="Address Line 1"
            variant="outlined"
          />
          <p className="text-danger">{errors?.addressLine1?.message}</p>
        </div>

        <div className="inputDiv">
          <TextField
            {...register("addressLine2")}
            type="text"
            className="inp"
            label="Address Line 2"
            variant="outlined"
          />
          <p className="text-danger">{errors?.addressLine2?.message}</p>
        </div>

        <div className="inputDiv">
          <TextField
            type="text"
            {...register("city")}
            className="inp"
            label="City"
            variant="outlined"
          />
          <p className="text-danger">{errors?.city?.message}</p>
        </div>

        <div className="inputDiv">
          <TextField
            type="text"
            {...register("state")}
            className="inp"
            label="State"
            variant="outlined"
          />
          <p className="text-danger">{errors?.state?.message}</p>
        </div>

        <div className="inputDiv">
          <TextField
            type="number"
            {...register("pincode")}
            className="inp"
            label="Pincode"
            variant="outlined"
          />
          <p className="text-danger">{errors?.pincode?.message}</p>
        </div>
        <Button type="submit" className="btn">
          Save
        </Button>
      </form>
    </div>
  );
}

export default AddressForm;
