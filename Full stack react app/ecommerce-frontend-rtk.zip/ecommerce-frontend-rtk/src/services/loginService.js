import jwt_decode from "jwt-decode";

const setToken = (token) => {
  localStorage.setItem("token", token);
};

const getToken = () => {
  return localStorage.getItem("token");
};

const isLoggedin = () => {
  const token = getToken();
  return !!token;
};

const removeToken = () => {
  localStorage.removeItem("token");
};

const getUser = (token) => {
  if (token) {
    const decodedUser = jwt_decode(token);
    return decodedUser;
  }
};

export { setToken, getToken, isLoggedin, removeToken, getUser };
