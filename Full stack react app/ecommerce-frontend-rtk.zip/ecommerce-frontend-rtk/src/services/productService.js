import Axios from "axios";

export const allData = async () => {
  const filterProducts = await Axios.get("http://localhost:9000/products").then(
    (res) => {
      if (res.data.success) {
        return res?.data?.product;
      }
    }
  );
  return filterProducts;
};
