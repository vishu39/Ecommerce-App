import "./dashboard.scss";
import Products from "../products/Products";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Appbar from "../../components/toolbar/Toolbar";
import SimpleBottomNavigation from "../../components/Bottombar/BottomBar";
import { getCarts } from "../../store/cartSlice";
import { getUser } from "../../services/loginService";
import { getUserAddress } from "../../store/addressSlice";

function Dashboard() {
  const dispatch = useDispatch();
  const token = useSelector((state) => state?.auth?.userToken);
  const carts = useSelector((state) => state?.carts?.carts);
  const user = getUser(token);

  useEffect(() => {
    if (carts.length === 0) {
      dispatch(getCarts(token));
    }
  }, [token]);

  // const getCart=(data)=>{
  // }

  // setTimeout(() => {
  //   // dispatch(getUserAddress(user?.userId));
  // }, 0);

  return (
    <div className="dashboard">
      <Appbar />
      <Products />
      {/* <SimpleBottomNavigation /> */}
    </div>
  );
}

export default Dashboard;
