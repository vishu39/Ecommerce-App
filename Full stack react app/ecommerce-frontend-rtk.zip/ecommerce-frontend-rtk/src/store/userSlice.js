import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import Axios from "axios";

const initialState = {
  loading: false,
  users: [],
  error: "",
};

const getUsers = createAsyncThunk("users/getUsers", async () => {
  const users = await Axios.get("http://localhost:9000/users").then((res) => {
    if (res.data.success) {
      return res?.data?.user;
    }
  });
  return users;
});

const userSlice = createSlice({
  name: "users",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getUsers.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getUsers.fulfilled, (state, action) => {
      state.loading = false;
      state.users = action.payload;
      state.error = "";
    });
    builder.addCase(getUsers.rejected, (state, action) => {
      state.loading = false;
      state.users = [];
      state.error = action.error.message;
    });
  },
});

export { getUsers };
export default userSlice.reducer;
