import React from "react";
import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { getUser } from "../../services/loginService";
import { getUserAddress } from "../../store/addressSlice";
import { getCarts } from "../../store/cartSlice";
import { getSingleUser } from "../../store/singleUserSlice";
import "./confirmOrder.scss";
import { toast } from "react-toastify";
import { Button } from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Appbar from "../../components/toolbar/Toolbar";
import { useNavigate } from "react-router-dom";

function ConfirmOrder() {
  const dispatch = useDispatch();
  const address = useSelector((state) => state?.address?.address);
  const token = useSelector((state) => state?.auth?.userToken);
  const userData = useSelector((state) => state?.singleUser?.user);
  const carts = useSelector((state) => state?.carts?.carts);

  const { userToken, isError, isSuccess, isLoading, message } = useSelector(
    (state) => state.auth
  );
  let priceArray = [];
  const user = getUser(token);
  const navigate = useNavigate();

  useEffect(() => {
    if (isError) {
      toast.error(message);
    }
    if (!userToken) {
      return navigate("/cart");
    }
  }, []);

  useEffect(() => {
    dispatch(getUserAddress(user?.userId));
    dispatch(getSingleUser(user?.userId));
    dispatch(getCarts(token));
  }, [token]);

  const grandTotal = () => {
    let sum = 0;
    for (let i = 0; i < priceArray.length; i++) {
      sum += priceArray[i];
    }
    return sum;
  };

  return (
    <div className="confirmOrder">
      <Appbar />

      <div className="main">
        <div className="user">
          <h3>User Details</h3>
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 500 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell align="center">User Id</TableCell>
                  <TableCell align="center">Name</TableCell>
                  <TableCell align="center">Email</TableCell>
                  <TableCell align="center">Phone no.</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                <TableRow
                  sx={{
                    "&:last-child td, &:last-child th": { border: 0 },
                  }}
                >
                  <TableCell align="center">{userData.userId}</TableCell>

                  <TableCell align="center">{userData.name}</TableCell>

                  <TableCell align="center">{userData.email}</TableCell>

                  <TableCell align="center" width="150">
                    {userData.phone}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </div>

        <div className="address">
          <h3>Address Details</h3>
          <TableContainer component={Paper}>
            <Table aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell align="center">AddressLine1</TableCell>
                  <TableCell align="center">AddressLine2</TableCell>
                  <TableCell align="center">City</TableCell>
                  <TableCell align="center">State</TableCell>
                  <TableCell align="center">Pincode</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {address.map((add, index) => {
                  return (
                    <TableRow
                      key={index}
                      sx={{
                        "&:last-child td, &:last-child th": { border: 0 },
                      }}
                    >
                      <TableCell align="center">{add.addressLine1}</TableCell>

                      <TableCell align="center">{add.addressLine2}</TableCell>

                      <TableCell align="center">{add.city}</TableCell>
                      <TableCell align="center">{add.state}</TableCell>
                      <TableCell align="center">{add.pincode}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </div>

        <div className="cartData">
          <h3>Product Details</h3>
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 500 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell align="center">S.No</TableCell>
                  <TableCell align="center">Name</TableCell>
                  <TableCell align="center">Category</TableCell>
                  <TableCell align="center">Quantity</TableCell>
                  <TableCell align="center">Price</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {carts?.map((cart, index) => {
                  return cart?.products?.map((data) => {
                    priceArray.push(data.productDetails.price * data.quantity);
                    return (
                      <TableRow
                        key={index}
                        sx={{
                          "&:last-child td, &:last-child th": { border: 0 },
                        }}
                      >
                        <TableCell align="center">{index + 1}</TableCell>

                        <TableCell align="center">
                          {data.productDetails.name}
                        </TableCell>

                        <TableCell align="center">
                          {data.productDetails.category}
                        </TableCell>

                        <TableCell align="center" width="150">
                          {data.quantity}
                        </TableCell>

                        <TableCell align="center">
                          {data.quantity * data.productDetails.price}
                        </TableCell>
                      </TableRow>
                    );
                  });
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      </div>
      <span className="total">
        <b>GrandTotal:</b>
        {grandTotal()}
      </span>

      <div className="bottomDiv">
        <Button
          onClick={() => navigate("/")}
          className="btn"
          variant="contained"
          color="primary"
        >
          Back To Dashboard
        </Button>
        <Button
          // onClick={() => navigate("/")}
          className="btn"
          variant="contained"
          color="success"
        >
          Book Order
        </Button>
      </div>
    </div>
  );
}

export default ConfirmOrder;
