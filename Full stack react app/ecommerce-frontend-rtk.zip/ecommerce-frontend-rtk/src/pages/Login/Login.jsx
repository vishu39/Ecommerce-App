import "./login.scss";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { reset, getLoginAuth } from "../../store/authSlice";
import { useSelector, useDispatch } from "react-redux";

import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import * as React from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import { useEffect } from "react";
import { getToken } from "../../services/loginService";

const schema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .email("Please enter valid Email"),
  password: yup.string().required("Password is required"),
});

function Login() {
  const { userToken, isError, isSuccess, isLoading, message } = useSelector(
    (state) => state.auth
  );

  const navigate = useNavigate();

  const dispatch = useDispatch();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    if (isError) {
      toast.error(message);
    }
    if (isSuccess || userToken) {
      navigate("/");
    }
    dispatch(reset());
  }, []);

  const submitHandler = (data) => {
    dispatch(getLoginAuth(data));
    navigate("/");
  };

  return (
    <div className="login">
      <div className="head">
        <h1>Login</h1>
      </div>
      <div className="main">
        <div className="first">
          <h3>
            If you are not a register user then click on the register button and
            register.
          </h3>
          <Button
            onClick={() => navigate("/register")}
            type="submit"
            className="btn"
            color="secondary"
            variant="contained"
            size="large"
          >
            Register
          </Button>
        </div>
        <form className="form" onSubmit={handleSubmit(submitHandler)}>
          <div className="inputDiv">
            <TextField
              {...register("email")}
              type="email"
              className="inp"
              label="Email"
              variant="outlined"
            />
            <p className="text-danger">{errors?.email?.message}</p>
          </div>

          <div className="inputDiv">
            <TextField
              type="password"
              {...register("password")}
              className="inp"
              label="Password"
              variant="outlined"
            />
            <p className="text-danger">{errors?.password?.message}</p>
          </div>
          <Button
            type="submit"
            className="btn"
            color="success"
            variant="contained"
          >
            Login
          </Button>
        </form>
      </div>
    </div>
  );
}

export default Login;
