import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import Axios from "axios";

const initialState = {
  loading: false,
  category: [],
  error: "",
};

const getCategory = createAsyncThunk("category/getCategory", async () => {
  const category = await Axios.get("http://localhost:9000/categories").then(
    (res) => {
      if (res.data.success) {
        return res.data.category;
      }
    }
  );
  return category;
});

const categorySlice = createSlice({
  name: "category",
  initialState,

  extraReducers: (builder) => {
    builder.addCase(getCategory.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getCategory.fulfilled, (state, action) => {
      state.loading = false;
      state.category = action.payload;
      state.error = "";
    });
    builder.addCase(getCategory.rejected, (state, action) => {
      state.loading = false;
      state.category = [];
      state.error = action.error.message;
    });
  },
});

export { getCategory };
export default categorySlice.reducer;
