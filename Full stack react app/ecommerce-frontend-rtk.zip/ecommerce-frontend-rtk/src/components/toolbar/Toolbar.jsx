import { useState, useEffect } from "react";
import "./toolbar.scss";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import { Button, IconButton } from "@mui/material";
import Tooltip from "@mui/material/Tooltip";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import AdminPanelSettingsOutlinedIcon from "@mui/icons-material/AdminPanelSettingsOutlined";
import { useNavigate } from "react-router-dom";
import Badge from "@mui/material/Badge";
import { isLoggedin, getUser } from "../../services/loginService";
import { useSelector, useDispatch } from "react-redux";
import { reset, userLogout } from "../../store/authSlice";
import AccountCircleRoundedIcon from "@mui/icons-material/AccountCircleRounded";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";

function Appbar() {
  const dispatch = useDispatch();
  const cartLength = useSelector((state) => state?.carts?.carts?.length);
  const token = useSelector((state) => state?.auth?.userToken);
  const cartFromStorage = useSelector(
    (state) => state?.notLogin?.notLoginData.length
  );
  const loginUser = getUser(token);
  const badgeCount = token ? cartLength : cartFromStorage;
  const navigate = useNavigate();

  useEffect(() => {}, [token]);

  const login = () => {
    navigate("/login");
  };

  const logout = () => {
    dispatch(userLogout());
    dispatch(reset());
    navigate("/login");
  };

  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <Box className="toolbar">
      <AppBar position="static" color="secondary">
        <Toolbar>
          <Typography variant="h4" component="div" sx={{ flexGrow: 1 }}>
            E-Commerce-App
          </Typography>

          <Button
            id="basic-button"
            aria-controls={open ? "basic-menu" : undefined}
            aria-haspopup="true"
            aria-expanded={open ? "true" : undefined}
            onClick={handleClick}
          >
            <AccountCircleRoundedIcon className="btnLink" />
          </Button>
          <Menu
            id="basic-menu"
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            MenuListProps={{
              "aria-labelledby": "basic-button",
            }}
          >
            <MenuItem>
              {loginUser?.role === "Admin" ? (
                <Tooltip title="Admin">
                  <IconButton
                    onClick={() => navigate("/admin")}
                    className="btnLink"
                  >
                    {/* <AdminPanelSettingsOutlinedIcon /> */}
                    Admin
                  </IconButton>
                </Tooltip>
              ) : (
                ""
              )}
            </MenuItem>
            <MenuItem>
              <Button
                onClick={() => {
                  navigate("/users/address");
                }}
                className="btnLink"
              >
                Address
              </Button>
            </MenuItem>
            <MenuItem>
              {isLoggedin() ? (
                <Tooltip title="Logout">
                  <Button onClick={() => logout()} className="btnLink">
                    Logout
                  </Button>
                </Tooltip>
              ) : (
                <Tooltip title="Login">
                  <Button onClick={() => login()} className="btnLink">
                    Login
                  </Button>
                </Tooltip>
              )}
            </MenuItem>
          </Menu>

          <Tooltip title="Cart">
            <IconButton onClick={() => navigate("/cart")} className="btnLink">
              <Badge badgeContent={badgeCount} color="error">
                <ShoppingCartIcon />
              </Badge>
            </IconButton>
          </Tooltip>
        </Toolbar>
      </AppBar>
    </Box>
  );
}

export default Appbar;
