import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

const initialState = {
  loading: false,
  filterProduct: [],
  error: "",
};

const getFilterProduct = createAsyncThunk(
  "products/getFilterProduct",
  async (data) => {
    return data;
  }
);

const filterProductSlice = createSlice({
  name: "filterProducts",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getFilterProduct.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getFilterProduct.fulfilled, (state, action) => {
      state.loading = false;
      state.filterProduct = action.payload;
      state.error = "";
    });
    builder.addCase(getFilterProduct.rejected, (state, action) => {
      state.loading = false;
      state.filterProduct = [];
      state.error = action.error.message;
    });
  },
});

export { getFilterProduct };
export default filterProductSlice.reducer;
