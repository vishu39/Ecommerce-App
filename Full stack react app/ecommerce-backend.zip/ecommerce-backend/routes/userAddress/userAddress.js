// const { UserAddress } = require("../../modal/user/address/userAddress");
// const asyncMiddleware = require("../../middleware/async");
// const express = require("express");
// const router = express.Router();

// router.get(
//   "/",
//   asyncMiddleware(async (req, res) => {
//     let address = await UserAddress.find({ userId: req.body.userId });
//     if (!address) {
//       return res.send({
//         success: false,
//         msg: "Address not found",
//       });
//     }

//     res.send({
//       success: true,
//       address,
//       msg: "Address found",
//     });
//   })
// );

// router.post(
//   "/",
//   asyncMiddleware(async (req, res) => {
//     const { userId, addressLine1, addressLine2, city, state, pincode } =
//       req.body;
//     let address = await UserAddress.findOne({ userId });
//     if (!address) {
//       return res.send({
//         success: false,
//         msg: "User Address not found",
//       });
//     }

//     address = new UserAddress({
//       userId,
//       addressLine1,
//       addressLine2,
//       city,
//       state,
//       pincode,
//     });

//     await address.save();

//     return res.send({
//       success: true,
//       address,
//       msg: "User Address added successfully",
//     });
//   })
// );

// module.exports = router;
