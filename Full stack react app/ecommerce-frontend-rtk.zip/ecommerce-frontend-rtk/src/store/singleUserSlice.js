import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import Axios from "axios";
import { getToken, getUser, user } from "../services/loginService";
import { getUserData } from "../services/userService";

const initialState = {
  loading: false,
  user: [],
  error: "",
};

const getSingleUser = createAsyncThunk(
  "singleUser/getSingleUser",
  async (userId) => {
    return getUserData(userId);
  }
);

const cartSlice = createSlice({
  name: "user",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getSingleUser.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getSingleUser.fulfilled, (state, action) => {
      state.loading = false;
      state.user = action.payload;
      state.error = "";
    });
    builder.addCase(getSingleUser.rejected, (state, action) => {
      state.loading = false;
      state.user = [];
      state.error = action.error.message;
    });
  },
});

export { getSingleUser };
export default cartSlice.reducer;
