import Axios from "axios";
import { getToken, getUser, removeToken, setToken } from "./loginService";

const logout = () => {
  removeToken();
};

const login = async (data) => {
  const response = await Axios.post("http://localhost:9000/users/login", data);
  if (response.data.success) {
    setToken(response.data.token);
    return response.data.token;
  }
};

const register = async (data) => {
  const response = await Axios.post(
    "http://localhost:9000/users/signup",
    data
  ).then((res) => {
    return res;
  });
  if (response.data.success) {
    setToken(response.data.token);

    return response.data.token;
  }
};

const addAddress = async (data) => {
  console.log(data);
  await Axios.post("http://localhost:9000/users/address", data).then((res) => {
    if (res.data.success) {
      console.log(res.data);
    }
  });
};

const editAddress = async (data) => {
  await Axios.put("http://localhost:9000/users/address", data).then((res) => {
    if (res.data.success) {
      console.log(res.data);
    }
  });
};

const getAddress = async (userId) => {
  const response = await Axios.get(
    `http://localhost:9000/users/address/${userId}`
  );
  if (response.data.success) {
    return response;
  }
};

const getUserData = async (userId) => {
  const response = await Axios.get(
    `http://localhost:9000/users/${userId}`
  ).then((res) => {
    return res;
  });
  if (response.data.success) {
    return response.data.user;
  }
};

export {
  logout,
  login,
  register,
  addAddress,
  editAddress,
  getAddress,
  getUserData,
};
