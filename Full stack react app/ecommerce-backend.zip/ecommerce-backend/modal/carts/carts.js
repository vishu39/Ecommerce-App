const mongoose = require("mongoose");
const { User } = require("../user/users");
const { Products } = require("../products/product");
const { generateId } = require("../../startup/uniqueId");

const cartSchema = new mongoose.Schema({
  cartId: {
    type: String,
  },
  userId: {
    type: String,
    ref: User,
  },
  date: {
    type: Date,
  },
  product: [
    {
      productId: {
        type: String,
        ref: Products,
      },
      quantity: {
        type: Number,
        default: 1,
      },
    },
  ],
});

cartSchema.methods.generateCartId = function () {
  return generateId("CID");
};

const Cart = mongoose.model("Carts", cartSchema);

module.exports.Cart = Cart;
