const mongoose = require("mongoose");
const { User } = require("../users");

const userAddressSchema = new mongoose.Schema({
  userId: {
    type: String,
    ref: User,
  },
  addressLine1: {
    type: String,
    required: true,
  },
  addressLine2: {
    type: String,
    required: true,
  },
  city: {
    type: String,
    required: true,
  },
  state: {
    type: String,
    required: true,
  },
  pincode: {
    type: Number,
    required: true,
  },
});

const UserAddress = mongoose.model("UserAddress", userAddressSchema);

module.exports.UserAddress = UserAddress;
