const mongoose = require("mongoose");

module.exports = function () {
  mongoose
    .connect("mongodb://localhost/Ecommerce-App")
    .then(() => console.log("Connected..."))
    .catch((err) => console.log("Error to connect", err));
};
