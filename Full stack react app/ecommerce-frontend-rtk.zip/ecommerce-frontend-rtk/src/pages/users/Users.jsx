import { Fragment, useEffect } from "react";
import axios from "axios";
import "./users.scss";
import { useSelector, useDispatch } from "react-redux";
import { getUsers } from "../../store/userSlice";

// --------------------------------------------
import { Button } from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

function Users() {
  const users = useSelector((state) => state?.users?.users);
  const dispatch = useDispatch();
  const isLoading = useSelector((state) => state?.users?.loading);

  useEffect(() => {
    dispatch(getUsers());
  }, []);

  const deleteUser = (userId) => {
    axios
      .delete(`http://localhost:9000/users/${userId}`)
      .then((res) => {
        console.log("Deleted....", res);
        dispatch(getUsers());
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="main">
      <h1>Users List</h1>
      <Fragment>
        {isLoading ? (
          <h1>Loading...</h1>
        ) : (
          <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell align="center">S.no</TableCell>
                  <TableCell align="center">UserID</TableCell>
                  <TableCell align="center">Name</TableCell>
                  <TableCell align="center">Email</TableCell>
                  <TableCell align="center">Password</TableCell>
                  <TableCell align="center">Phone</TableCell>
                  <TableCell align="center">Role</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {users?.map((user, index) => {
                  return (
                    <TableRow
                      key={index}
                      sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    >
                      <TableCell align="center">{index + 1}</TableCell>
                      <TableCell align="center">{user.userId}</TableCell>
                      <TableCell align="center">{user.name}</TableCell>
                      <TableCell align="center">{user.email}</TableCell>
                      <TableCell align="center">{user.password}</TableCell>
                      <TableCell align="center">{user.phone}</TableCell>
                      <TableCell align="center">{user.role}</TableCell>
                      <TableCell align="center">
                        <Button color="secondary">Edit</Button>
                        <Button
                          color="error"
                          onClick={() => deleteUser(user._id)}
                        >
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </Fragment>
    </div>
  );
}

export default Users;
