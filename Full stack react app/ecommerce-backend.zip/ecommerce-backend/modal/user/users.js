const mongoose = require("mongoose");
const yup = require("yup");
const config = require("config");
const jwt = require("jsonwebtoken");
const { generateId } = require("../../startup/uniqueId");

const userSchema = new mongoose.Schema({
  userId: {
    type: String,
  },
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  phone: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    default: "user",
  },
});

userSchema.methods.generateAuthToken = function () {
  const token = jwt.sign(
    { userId: this.userId, role: this.role },
    config.get("jwtPrivateKey")
  );
  return token;
};

userSchema.methods.generateUserId = function () {
  return generateId("UID");
};

const User = mongoose.model("User", userSchema);

module.exports.User = User;
