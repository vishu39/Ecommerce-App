import "./addproduct.scss";
import { useForm } from "react-hook-form";

import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import * as React from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";

const schema = yup.object().shape({
  name: yup.string().required("Name is required"),
  price: yup
    .number()
    .transform((value) => (isNaN(value) ? undefined : value))
    .required("Price is required"),
  category: yup.string().required("Category is required"),
  image: yup.string().required("Image is required"),
  description: yup.string().required("Description is required"),
});

function AddProducts() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const submitHandler = (data) => {
    console.log(data);
    // const formData = new FormData();
    // formData.append("name", data.name);
    // formData.append("price", data.price);
    // formData.append("category", data.category);
    // formData.append("image", data.image[0]);
    // formData.append("description", data.description);
    // Axios.post("http://localhost:9000/products", formData)
    //   .then(function (response) {
    //     console.log(response);
    //   })
    //   .catch(function (error) {
    //     console.log(error);
    //   });
  };

  return (
    <div className="addProduct">
      <form className="form" onSubmit={handleSubmit(submitHandler)}>
        <div className="heading">
          <h1>Add Product</h1>
        </div>

        <div className="inputDiv">
          <TextField
            {...register("name")}
            className="inp"
            label="Name"
            variant="outlined"
          />
          <p className="text-danger">{errors?.name?.message}</p>
        </div>

        <div className="inputDiv">
          <TextField
            {...register("price")}
            type="number"
            className="inp"
            label="Price"
            variant="outlined"
          />
          <p className="text-danger">{errors?.price?.message}</p>
        </div>

        <div className="inputDiv">
          <TextField
            {...register("category")}
            className="inp"
            label="Category"
            variant="outlined"
          />
          <p className="text-danger">{errors?.category?.message}</p>
        </div>

        <div className="inputDiv">
          <TextField
            type="file"
            {...register("image")}
            className="inp"
            variant="outlined"
          />
          <p className="text-danger">{errors?.image?.message}</p>
        </div>

        <div className="inputDiv">
          <TextField
            type="password"
            {...register("description")}
            className="inp"
            label="Description"
            variant="outlined"
          />
          <p className="text-danger">{errors?.description?.message}</p>
        </div>
        <Button type="submit" className="btn" color="error" variant="contained">
          Add Product
        </Button>
      </form>
    </div>
  );
}

export default AddProducts;

// -----------------------------------------------------------------------------------------------------------------------

// <div className="addProduct">
//   <div className="form">
//     <form
//       onSubmit={handleSubmit(submitHandler)}
//       encType="multipart/form-data"
//     >
//       <div className="inputDiv">
//         <label>Name</label>
//         <input {...register("name")} type="text" />
//         <p className="text-danger">{errors?.name?.message}</p>
//       </div>
//       <div className="inputDiv">
//         <label>Price</label>
//         <input {...register("price")} type="number" />
//         <p className="text-danger">{errors?.price?.message}</p>
//       </div>
//       <div className="inputDiv">
//         <label>Category</label>
//         <select {...register("category")}>
//           <option></option>
//           <option>Clothing</option>
//           <option>Electronic</option>
//           <option>Sport</option>
//           <option>Jewelery</option>
//           <option>Wearables</option>
//         </select>
//         <p className="text-danger">{errors?.category?.message}</p>
//         {/* <input {...register("category")} type="text" /> */}
//       </div>
//       <div className="inputDiv">
//         <label>Image</label>
//         <input {...register("image")} type="file" />
//         <p className="text-danger">{errors?.image?.message}</p>
//       </div>
//       <div className="inputDiv">
//         <label>Description</label>
//         <textarea {...register("description")}></textarea>
//         {/* <input  type="text" /> */}
//         <p className="text-danger">{errors?.description?.message}</p>
//       </div>
//       <button type="submit">Submit</button>
//     </form>
//   </div>
// </div>
