import "./product.scss";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import { useNavigate } from "react-router-dom";
import Category from "./Category";
import { useSelector, useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import { getFilterProduct } from "../../store/filterProductSlice";
import { allData } from "../../services/productService";
import { getProducts } from "../../store/productSlice";
import { getCategory } from "../../store/categorySlice";

function Products() {
  const allProduct = useSelector((state) => state?.products?.products);
  let category = useSelector((state) => state?.category?.category);
  // const [selectedFilter, setSelectedFilter] = useState("all");
  const filterProduct = useSelector(
    (state) => state?.filterProduct?.filterProduct
  );
  const dispatch = useDispatch();

  useEffect(() => {
    const product = allData();
    dispatch(getProducts(product));
    dispatch(getFilterProduct(product));
    dispatch(getCategory());
    // document.getElementById("all").classList.add("selected");
  }, []);

  // const higlightFilter = (filterName) => {
  //   const allBtn = document.getElementById("all");
  //   const clothingBtn = document.getElementById("Clothing");
  //   const electronicBtn = document.getElementById("Electronics");
  //   const wearableBtn = document.getElementById("Wearables");
  //   const jeweleryBtn = document.getElementById("Jewelery");

  //   if (filterName === "all") {
  //     allBtn.classList.add("selected");
  //   } else {
  //     allBtn.classList.remove("selected");
  //   }
  //   if (filterName === "Clothing") {
  //     clothingBtn.classList.add("selected");
  //   } else {
  //     clothingBtn.classList.remove("selected");
  //   }
  //   if (filterName === "Electronics") {
  //     electronicBtn.classList.add("selected");
  //   } else {
  //     electronicBtn.classList.remove("selected");
  //   }
  //   if (filterName === "Wearables") {
  //     wearableBtn.classList.add("selected");
  //   } else {
  //     wearableBtn.classList.remove("selected");
  //   }
  //   if (filterName === "Jewelery") {
  //     jeweleryBtn.classList.add("selected");
  //   } else {
  //     jeweleryBtn.classList.remove("selected");
  //   }
  // };

  const allCat = () => {
    dispatch(getFilterProduct(allProduct));
    // higlightFilter("all");
  };

  const fetchCategory = (cat) => {
    // setSelectedFilter(cat);
    let item = [];
    item = allProduct.filter((product) => {
      if (product.category === cat) {
        return product;
      }
    });
    dispatch(getFilterProduct(item));
  };

  const navigate = useNavigate();

  return (
    <div className="product">
      <Category
        category={category}
        fetchCategory={fetchCategory}
        allCat={allCat}
        // higlightFilter={higlightFilter}
      />
      <div className="cardDiv">
        {
          // isProductLoading ? (
          //   <h1>Loading...</h1>
          // ) :

          filterProduct?.map((product, index) => {
            return (
              <Card
                className="card"
                onClick={() => {
                  navigate(`product/${product?.productId}`);
                }}
                key={index}
              >
                <CardActionArea>
                  <CardMedia
                    component="img"
                    className="img"
                    image={`http://localhost:9000/${product?.image}`}
                  />
                  <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                      {product?.name}
                    </Typography>
                    <Typography gutterBottom variant="body2" component="div">
                      {product?.category}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {product?.price}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {product?.description}
                    </Typography>
                  </CardContent>
                </CardActionArea>
                {/* <CardActions>
                </CardActions> */}
              </Card>
            );
          })
        }
      </div>
    </div>
  );
}

export default Products;

// -------------------------------------------------------------------------------
