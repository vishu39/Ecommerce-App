const validate = (schema) => async (req, res, next) => {
  const body = req.body;

  try {
    await schema.validate(body);
    next();
  } catch (ex) {
    return res.status(400).send({
      msg: ex.message,
      error: ex,
    });
  }
};

module.exports.validate = validate;
