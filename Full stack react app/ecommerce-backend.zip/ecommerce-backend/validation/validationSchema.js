const yup = require("yup");

const registerSchema = yup.object().shape({
  name: yup.string().required("Name is required"),
  email: yup.string().required().email(),
  phone: yup.string().required(),
  password: yup.string().required(),
});

const loginSchema = yup.object({
  email: yup.string().required().email(),
  password: yup.string().required(),
});

const cartSchema = yup.object().shape({
  userId: yup.string().required("User id is required"),
  product: yup.array().of(
    yup.object().shape({
      productId: yup.string().required("ProductId is required"),
      quantity: yup.number().required("Quantity is required"),
    })
  ),
});

const productSchema = yup.object({
  name: yup.string().required(),
  price: yup.number().required(),
  // image: yup.string().required(),
  category: yup.string().required(),
  description: yup.string().required(),
});

module.exports.registerSchema = registerSchema;
module.exports.loginSchema = loginSchema;
module.exports.cartSchema = cartSchema;
module.exports.productSchema = productSchema;
