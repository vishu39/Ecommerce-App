import "./register.scss";
import { useForm } from "react-hook-form";
import Axios from "axios";

import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useNavigate } from "react-router-dom";

import * as React from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import logo from "./bgg.jpeg";
import { useDispatch } from "react-redux";
import { getRegisterAuth } from "../../store/authSlice";

const schema = yup.object().shape({
  name: yup.string().required("Name is required"),
  email: yup
    .string()
    .required("Email is required")
    .email("Please enter valid Email"),
  phone: yup
    .number()
    .transform((value) => (isNaN(value) ? undefined : value))
    .required("Phone number is required"),
  password: yup.string().required("Password is required"),
});

function Register() {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const submitHandler = (data) => {
    dispatch(getRegisterAuth(data));
    navigate("/");
    // Axios.post("http://localhost:9000/users/signup", data)
    //   .then(function (res) {
    //     navigate("/");
    //   })
    //   .catch(function (error) {
    //     console.log(error);
    //   });
  };

  return (
    <div className="register">
      <div className="main">
        <div className="imageDiv">
          <img className="img" src={logo}></img>
        </div>
        <form className="form" onSubmit={handleSubmit(submitHandler)}>
          <div className="heading">
            <h1>Register</h1>
          </div>

          <div className="inputDiv">
            <TextField
              {...register("name")}
              className="inp"
              label="Name"
              variant="outlined"
            />
            <p className="text-danger">{errors?.name?.message}</p>
          </div>

          <div className="inputDiv">
            <TextField
              {...register("email")}
              type="email"
              className="inp"
              label="Email"
              variant="outlined"
            />
            <p className="text-danger">{errors?.email?.message}</p>
          </div>

          <div className="inputDiv">
            <TextField
              type="number"
              {...register("phone")}
              className="inp"
              label="Phone No."
              variant="outlined"
            />
            <p className="text-danger">{errors?.phone?.message}</p>
          </div>

          <div className="inputDiv">
            <TextField
              type="password"
              {...register("password")}
              className="inp"
              label="Password"
              variant="outlined"
            />
            <p className="text-danger">{errors?.password?.message}</p>
          </div>
          <Button
            type="submit"
            className="btn"
            color="secondary"
            variant="contained"
          >
            Register
          </Button>
        </form>
      </div>
    </div>
  );
}

export default Register;
