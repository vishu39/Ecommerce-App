const generateId = (prefix = "") => {
  const uniqueId = `${prefix}${Date.now()}`;
  return uniqueId;
};

module.exports.generateId = generateId;
