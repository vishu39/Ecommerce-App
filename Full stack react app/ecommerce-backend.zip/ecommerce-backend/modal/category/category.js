const mongoose = require("mongoose");
const { generateId } = require("../../startup/uniqueId");

const categorySchema = new mongoose.Schema({
  categoryId: {
    type: String,
    required: true,
  },

  categoryName: {
    type: String,
    required: true,
  },
});

categorySchema.methods.generateCategoryId = function () {
  return generateId("CATID");
};

const Category = mongoose.model("Category", categorySchema);

module.exports.Category = Category;
