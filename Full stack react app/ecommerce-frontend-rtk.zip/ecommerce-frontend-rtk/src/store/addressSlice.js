import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { getAddress } from "../services/userService";

const initialState = {
  loading: false,
  address: [],
  error: "",
};

const getUserAddress = createAsyncThunk(
  "address/getUserAddress",
  async (userId) => {
    const address = await getAddress(userId);
    return address.data.address;
  }
);

const addressSlice = createSlice({
  name: "address",
  initialState,
  extraReducers: (builder) => {
    builder.addCase(getUserAddress.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getUserAddress.fulfilled, (state, action) => {
      state.loading = false;
      state.address = action.payload;
      state.error = "";
    });
    builder.addCase(getUserAddress.rejected, (state, action) => {
      state.loading = false;
      state.address = [];
      state.error = action.error.message;
    });
  },
});

export { getUserAddress };
export default addressSlice.reducer;
