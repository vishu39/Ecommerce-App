import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { getToken, getUser } from "../services/loginService";
import { login, logout, register } from "../services/userService";
const token = getToken();

const initialState = {
  userToken: token ? token : null,
  isError: false,
  isSuccess: false,
  isLoading: false,
  message: "",
};

export const getLoginAuth = createAsyncThunk(
  "auth/getLoginAuth",
  async (data, thunkAPI) => {
    try {
      const token = await login(data);
      return token;
    } catch (error) {
      const message =
        (error.response &&
          error.response.data &&
          error.response.data.message) ||
        error.message ||
        error.toString();
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const getRegisterAuth = createAsyncThunk(
  "auth/getRegisterAuth",
  async (data, thunkAPI) => {
    try {
      return await register(data);
    } catch (error) {
      const message =
        (error.response &&
          error.response.data &&
          error.response.data.message) ||
        error.message ||
        error.toString();
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const userLogout = createAsyncThunk("auth/logout", async () => {
  logout();
});

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    reset: (state) => {
      state.isLoading = false;
      state.userToken = "";
      state.isSuccess = false;
      state.isError = false;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getLoginAuth.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(getLoginAuth.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      state.userToken = action.payload;
    });
    builder.addCase(getLoginAuth.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
      state.userToken = null;
    });

    builder.addCase(getRegisterAuth.pending, (state) => {
      state.isLoading = true;
    });
    builder.addCase(getRegisterAuth.fulfilled, (state, action) => {
      state.isLoading = false;
      state.isSuccess = true;
      state.userToken = action.payload;
    });
    builder.addCase(getRegisterAuth.rejected, (state, action) => {
      state.isLoading = false;
      state.isError = true;
      state.message = action.payload;
      state.userToken = null;
    });

    builder.addCase(userLogout.fulfilled, (state) => {
      state.userToken = null;
    });
  },
});

export const { reset } = authSlice.actions;
export default authSlice.reducer;
