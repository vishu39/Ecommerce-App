import { createSlice, createAsyncThunk, current } from "@reduxjs/toolkit";
import Axios from "axios";
import { getToken, getUser, user } from "../services/loginService";

const initialState = {
  loading: false,
  carts: [],
  error: "",
};

const getCarts = createAsyncThunk("carts/getCarts", async (token) => {
  const userId = await getUser(token);
  const carts = await Axios.get(`http://localhost:9000/cart/${userId?.userId}`);
  if (carts.data.success) {
    return carts?.data?.cart?.cartData;
  }
});

// const incrementQuantity = createAsyncThunk(
//   "carts/incrementQuantity",
//   (data) => {
//     // let updated = data.carts.map((cart) => {
//     //   if (cart.cartId === data.cartId) {
//     //     cart.products.map((item) => {
//     //       item = {
//     //         productId: item.productId,
//     //         productDetails: item.productDetails,
//     //         quantity: item.quantity + 1,
//     //       };
//     //       return item;
//     //     });
//     //   }
//     //   console.log(updated);
//     // });
//     // console.log(updated);
//     data.carts[data.index].products[0].quantity =
//       data.carts[data.index].products[0].quantity + 1;
//     return data.carts;
//     // console.log(data);
//   }
// // );
// const decrementQuantity = createAsyncThunk("", () => {});

const cartSlice = createSlice({
  name: "carts",
  initialState,
  reducers: {
    incrementQuantity: (state, action) => {
      // let cart = current(state).carts[action.payload];
      let cart = JSON.parse(JSON.stringify(state.carts));
      let nCart = cart[action.payload];
      let newCart = nCart.products.map((pro) => {
        return {
          productId: pro.productId,
          productDetails: pro.productDetails,
          quantity: pro.quantity + 1,
        };
      });
      newCart.map((nc) => {
        nCart.products[0] = nc;
      });
      cart[action.payload] = nCart;
      state.carts = cart;
    },

    decrementQuantity: (state, action) => {
      // let cart = current(state).carts[action.payload];
      let cart = JSON.parse(JSON.stringify(state.carts));
      let nCart = cart[action.payload];
      let newCart = nCart.products.map((pro) => {
        return {
          productId: pro.productId,
          productDetails: pro.productDetails,
          quantity: pro.quantity - 1,
        };
      });
      newCart.map((nc) => {
        nCart.products[0] = nc;
      });
      cart[action.payload] = nCart;
      state.carts = cart;
    },
    updateCart: (state, action) => {
      console.log(action.payload);
    },
  },

  extraReducers: (builder) => {
    builder.addCase(getCarts.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(getCarts.fulfilled, (state, action) => {
      state.loading = false;
      state.carts = action.payload;
      state.error = "";
    });
    builder.addCase(getCarts.rejected, (state, action) => {
      state.loading = false;
      state.carts = [];
      state.error = action.error.message;
    });
    // builder.addCase(incrementQuantity.fulfilled, (state, action) => {
    //   console.log(action.payload);
    //   // state.loading = false;
    //   // state.carts = action.payload;
    //   // state.error = "";
    // });
  },
});

export { getCarts };
export const { incrementQuantity, decrementQuantity, updateCart } =
  cartSlice.actions;
export default cartSlice.reducer;
