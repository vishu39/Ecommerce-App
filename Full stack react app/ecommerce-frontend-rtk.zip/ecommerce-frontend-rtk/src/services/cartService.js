import Axios from "axios";

const deleteCart = async (cartId) => {
  await Axios.delete(`http://localhost:9000/cart/${cartId}`);
};

const updateCart = async (cartId, body) => {
  await Axios.put(`http://localhost:9000/cart/${cartId}`, body);
};

export { deleteCart, updateCart };
