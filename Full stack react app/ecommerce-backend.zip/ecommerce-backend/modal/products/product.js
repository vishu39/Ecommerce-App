const mongoose = require("mongoose");
const { generateId } = require("../../startup/uniqueId");
const yup = require("yup");

const productSchema = new mongoose.Schema({
  productId: {
    type: String,
  },
  name: {
    type: String,
    required: true,
    unique: true,
  },
  price: {
    type: Number,
    required: true,
  },
  category: {
    type: String,
    required: true,
  },
  image: {
    type: String,
    contentType: "image",
  },
  description: {
    type: String,
    required: true,
  },
});

productSchema.methods.generateProductId = function () {
  return generateId("PID");
};

const Products = mongoose.model("products", productSchema);

module.exports.Products = Products;
